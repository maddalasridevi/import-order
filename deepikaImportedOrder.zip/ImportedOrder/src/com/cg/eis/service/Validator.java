package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.exception.QuantityException;

public class Validator {
	
	
	
//isQuantityValid method validates if the quantity is valid.

      //If yes, return true else, throw QuantityException
	public static boolean isQuantityValid(int quantity) throws QuantityException {
		if(quantity > 0) {
			return true;
		}
		else {
			throw new QuantityException();
		}
	}

        
 //isPriceValid method validates if the price is valid.

       //If yes, return true else, return false
       public static boolean isPriceValid(double price){
    	   Scanner sc = new Scanner(System.in);
    	   while(true) {
	    	   if(price > 0) {
	    		   return true;
	    	   }
	    	   else {
	    		   System.out.println("Price should be greater than 0");
	    		   return false;
	    	   }
    	   }
       }
	
}
