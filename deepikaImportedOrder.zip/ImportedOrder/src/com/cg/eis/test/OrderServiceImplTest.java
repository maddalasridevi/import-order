package com.cg.eis.test;



import com.cg.eis.bean.Order;
import com.cg.eis.service.OrderServiceImpl;

//JUnit Test

public class OrderServiceImplTest {	
	

}
