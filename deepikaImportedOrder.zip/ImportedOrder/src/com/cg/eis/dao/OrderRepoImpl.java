package com.cg.eis.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Order;

//Relate this class to OrderRepo interface
public class OrderRepoImpl implements OrderRepo{
	// Map to store orders where key->Order:id and value->Order:object
	private static Map<Integer, Order> orderList = new HashMap<>();
	
	public static Map<Integer, Order> getOrderList() {
		return orderList;
	}

	public static void setOrderList(Map<Integer, Order> orderList) {
		OrderRepoImpl.orderList = orderList;
	}

	@Override
	public int saveOrder(Order bean) {
		orderList.put(bean.getId(), bean);
		return 0;
	}

	@Override
	public Collection<Order> getAllOrders() {
		if(orderList.isEmpty()) {
			return null;
		}
		else {
			return orderList.values();
		}
	}

	
	// implement the abstract methods in the interface	
	
}
